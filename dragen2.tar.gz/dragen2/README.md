# DRAGEN2

Run the benchmarks using stack:

```
stack setup
stack bench
```
